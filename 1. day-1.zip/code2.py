name = input('enter name  :')
hs = input('enter data :')
es = input('enter data :')
cs = input('enter data :')

print(type(hs))

total = int(hs) + int(es) + int(cs)

print(total)
