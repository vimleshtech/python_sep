#data type
a = 1# int
print(type(a))


a = 1.333 # float 
print(type(a))


a = '1.333' # str
print(type(a))


a = "1.333" # str
print(type(a))


a = True # bool
print(type(a))


a = [1,2,3,4,5] # list
print(type(a))

a = (1,23,3,4) # tuple
print(type(a))

d ={'a':'alpha','b':'beta','c':'ceta'}#dict
print(type(d))


d = {'dove','lux','dove'} #set
print(type(d))
print(d)






