a =11#int
print(type(a))


a =11.3434#float
print(type(a))

a = '11' #str
print(type(a))


a = "11" #str
print(type(a))

a = True #bool
print(type(a))

a = [1,2,3,4,5] # list
print(type(a))

a = (1,2,3,4,5)# tuple
print(type(a))


a ={1:'one',2:'two',3:'three'} #dict
print(type(a))

a = {'dove','lux'} #set 
print(type(a))






