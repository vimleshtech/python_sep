#take a number from user and check no. is even or odd
n = int(input('enter number :'))
if n%2 ==0:
     print('give no. is even ')
else:
     print('given no. is odd ')



#take three numbers from user and show greater no.
a = int(input('enter number :'))
b = int(input('enter number :'))
c = int(input('enter number :'))

if a>b and a>c:
     print('a is gt')
elif b>a and b>c:
     print('b is gt')
else:
     print('c is gt')
     

     
