#python does allocate memory automatically

a = 1  # here a is variable and 1 is data or value
b =44 
c = a+b # expression / logic

print('sum of two numbers : ',c) # outuput 

a ='1'

