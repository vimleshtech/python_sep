a =1
b =4
c =a+b

print c
print (c)


##input
a= input('enter data :' )
b = input('enter data :')

c = a+b
print 'sum of two numbers  :',c


#read name
#default data type is string
n = raw_input('read name :' )# this function will not work in python 3.0>=

print 'you have entered : ' ,n

## check data type
a =1 # int
print type(a)


a =33.44 # float
print type(a)

a ='1' # str
print type(a)
a ="1" # str
print type(a)

a = True # bool
print type(a)

a =[111,2,2,34,5]  # list
print type(a)

a = (1,2,3,4,5)  # tuple (read only )
print type(a)

a ={'a':'alpha','b':'beta','c':'ceta'}  # dict
print type(a)

a = {'dove','lux','dove'}   # set : contains unique value only
print type(a)
print a











