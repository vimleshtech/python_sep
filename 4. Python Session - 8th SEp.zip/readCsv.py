#read data from .csv

import pandas

df = pandas.read_csv("C:\Users\Public.LAPTOP-7FAGM1SH\Desktop\Python_ML_DS\data\emp.csv")

print df

print df.shape

print df.head(n=2)
print df.tail(n=1)

print df['name']


print df[0:2]#slicer

#show basic stats
print df.describe()


#disribuation / group by
print df.groupby('gender').size()
print df.groupby('gender').max()
print df.groupby('gender').min()
print df.groupby('gender').sum()



df.to_csv("C:\Users\Public.LAPTOP-7FAGM1SH\Desktop\Python_ML_DS\data\out.csv", sep=',', encoding='utf-8')






