f = open('C:\Users\Public.LAPTOP-7FAGM1SH\Desktop\Python_ML_DS\data\emp.txt','r')
# r : read (open the file in read mode )
'''
read()      : read all content from file
readline()  : read line by line line (read first line )
readlines()  : read all lines and convert to list (array)
            : every line of file wil become an element of list
write()     : write data to file
close()     : save and close the file 
'''


#print f
#print f.read()
#print f.readline()
#print f.readline()

#print f.readlines()
data = f.readlines() #read data from file and store on variable 

rc = len(data)  # get count of element from list

print 'no of rows :',rc 


#read line by line
for l in data:
    print l


f.close()
