f = open('C:\Users\Public.LAPTOP-7FAGM1SH\Desktop\Python_ML_DS\data\emp.txt','a')
# w:write  : overwrite the data if data is present

# a: append

for i in range(1,5):
    d = raw_input('enter data : ')    
    f.write('\n'+d)

    
f.close()





