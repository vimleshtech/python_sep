import shutil

shutil.copy(src,dest)
