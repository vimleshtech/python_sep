def add(a,b):
    print(a+b)

def sub(a,b):
    return a-b

