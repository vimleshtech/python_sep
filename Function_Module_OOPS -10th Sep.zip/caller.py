import calc

calc.add(11,3)
a = calc.sub(11,3)

print(a)

#or
from calc import add
add(11,3)

#or
import calc as c
c.add(11,3)
