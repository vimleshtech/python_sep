'''
Stat Function (only for numeric columns)
=======================
-max()
-min()
-avg / mean()

-range()
       max() - min()
-median
     example: 1 2 3 4 5
      3
     example: 1 2 3 4 5 6
                3+4 = 7
                7/2 = 3.5
-quantile
     25%  2
     50%   4
     75%   6
     100%   8
     example: 1 2 3 4 5 6  7 8    
     

-pecentile
     13%
     46%
     99%

-k-means
     
-cluster


-var

-std dev. 

          
                
                
      
       
       
'''
