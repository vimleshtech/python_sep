import mysql.connector #import module 
c = mysql.connector.connect(host='localhost',user='root',password='root',database='hrms')

cr = c.cursor() #to run sql command
cr.execute('select * from emp')

res = cr.fetchall()
for r in res:
     print(r)

