#import tkinter
from tkinter import *


     
o = Tk()

l1 = Label(text='enter nu : ')
l1.pack()

t1 = Entry()
t1.pack()

l2 = Label(text='enter nu : ')
l2.pack()

t2 = Entry()
t2.pack()

out = Label(text='')
out.pack()


def fun1():
     print('you have clicked on function')
     a = t1.get()
     b = t2.get()
     #c =int(a) + int(b)
     #print(c)
     c = ''
     for i in range(1,10):
          c += str(i)+'\t'+str((i*5))+'\n'
          
     out.configure(text=str(c))
     
     
btn = Button(text='Click Me',command=fun1)
btn.pack()

o.mainloop()


