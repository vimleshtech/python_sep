import time
import threading

def process1():     
     for i in range(1,5):
          
          print(i)
          time.sleep(1)
     

def process2():
     for i in range(10,15):
          print(i)
          time.sleep(1)
      
##call to function
#process1()

p1 = threading.Thread(target=process1,name='process1')
#p2 = threading.Thread(target=process2,name='process2')
#p3 = threading.Thread(target=process1,name='process3')

p1.start()
#p2.start()
#p3.start()


print (p1.isAlive())

#p1._stop()






          
          
